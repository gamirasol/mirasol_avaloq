import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvaloqHeaderComponent } from './avaloq-header.component';

describe('AvaloqHeaderComponent', () => {
  let component: AvaloqHeaderComponent;
  let fixture: ComponentFixture<AvaloqHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvaloqHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvaloqHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
