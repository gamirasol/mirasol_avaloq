import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-avaloq-header',
  templateUrl: './avaloq-header.component.html',
  styleUrls: ['./avaloq-header.component.css']
})
export class AvaloqHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
