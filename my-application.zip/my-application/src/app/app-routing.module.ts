import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AvaloqDiceMainComponent } from './avaloq-dice-main/avaloq-dice-main.component'

const routes: Routes = [
  {path: '', component: AvaloqDiceMainComponent},
  {path: 'home', component: AvaloqDiceMainComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
