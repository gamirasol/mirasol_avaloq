import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AvaloqDiceMainComponent } from './avaloq-dice-main/avaloq-dice-main.component';
import { AvaloqDiceTableComponent } from './avaloq-dice-table/avaloq-dice-table.component';
import { AvaloqHeaderComponent } from './avaloq-header/avaloq-header.component';
import { AvaloqFooterComponent } from './avaloq-footer/avaloq-footer.component';

@NgModule({
  declarations: [
    AppComponent,
    AvaloqDiceMainComponent,
    AvaloqDiceTableComponent,
    AvaloqHeaderComponent,
    AvaloqFooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
