import { TestBed } from '@angular/core/testing';

import { AvaloqService } from './avaloq.service';

describe('AvaloqService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AvaloqService = TestBed.get(AvaloqService);
    expect(service).toBeTruthy();
  });
});
