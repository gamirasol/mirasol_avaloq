import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { RollResult, SimulationRoll, Validation } from '../avaloq-dice-main/avaloq-dice-main.component';

@Injectable({
  providedIn: 'root'
})
export class AvaloqService {

  constructor(private http: HttpClient) { }

  processNormalDice(){
    return this.http.get<RollResult[]>('http://localhost:4200/avaloq/processNormalRoll')
  }

  processCustomizeRoll(numOfDice, sideOfDice, totalRolls){
    return this.http.get<RollResult[]>(`http://localhost:4200/avaloq/processCustomizeRoll/numOfDice/${numOfDice}/sideOfDice/${sideOfDice}/totalRolls/${totalRolls}`)
  }

  getSimulationRoll(){
    return this.http.get<SimulationRoll>('http://localhost:4200/avaloq/getSimulationRoll')
  }

  validateEntry(numOfDice, sideOfDice, totalRolls){
    return this.http.get<Validation>(`http://localhost:4200/avaloq/validateEntry/numOfDice/${numOfDice}/sideOfDice/${sideOfDice}/totalRolls/${totalRolls}`)
  }

}
