import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvaloqDiceMainComponent } from './avaloq-dice-main.component';

describe('AvaloqDiceMainComponent', () => {
  let component: AvaloqDiceMainComponent;
  let fixture: ComponentFixture<AvaloqDiceMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvaloqDiceMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvaloqDiceMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
