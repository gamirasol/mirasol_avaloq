import { Component, OnInit } from '@angular/core';
import { AvaloqService } from '../service/avaloq.service';

export class RollResult{
  constructor(
    public diceSum: Number,
    public count: Number
  ){}
}

export class SimulationRoll{
  constructor(
    public normalTotalSumRoll: Number,
    public normalTotalRoll: Number,
    public customizeTotalSumRoll: Number,
    public customizeTotalRoll: Number,
    public totalRoll: Number,
    public totalSumRoll: Number
  ){}
}

export class Validation{
  constructor(public errorMessage: String){}
}

@Component({
  selector: 'app-avaloq-dice-main',
  templateUrl: './avaloq-dice-main.component.html',
  styleUrls: ['./avaloq-dice-main.component.css']
})
export class AvaloqDiceMainComponent implements OnInit {

  constructor(private service: AvaloqService) { }

  numOfDice : Number
  sideOfDice : Number
  totalRolls : Number
  rollResultList: RollResult[]
  displayResult = ''
  simulationRoll: SimulationRoll
  displaySRResult = ''
  errorMessage : String
  validation: Validation

  ngOnInit() {
  }

  rollNormalDice(){
    this.errorMessage = ''
    this.numOfDice = 0
    this.sideOfDice = 0
    this.totalRolls = 0
    console.log('rollNormalDice')
    this.service.processNormalDice().subscribe(
      response =>{
        console.log('response: '+response)
        this.rollResultList = response;
        this.displayResult = 'Y'
        this.getSimulationRoll();
    }, error => {
      this.errorMessage = error
    })
  }
  rollCustomizeDice(){
    this.errorMessage = ''
    console.log('rollCustomizeDice: numOfDice: '+this.numOfDice+' sideOfDice: '+this.sideOfDice+' totalRolls: '+this.totalRolls)
    if (this.numOfDice == null || this.sideOfDice == null || this.totalRolls == null){
      this.errorMessage = 'Invalid Number of Dice!'
      return;
    }else if(this.sideOfDice == null){
      this.errorMessage = 'Invalid Number Side of Dice!'
      return;
    }else if(this.totalRolls == null){
      this.errorMessage = 'Invalid Number Total Rolls!'
      return;
    }else{
      this.service.validateEntry(this.numOfDice, this.sideOfDice, this.totalRolls).subscribe(
        response =>{
          console.log('response: '+response)
          this.validation = response
          this.errorMessage = this.validation.errorMessage;
          console.log('errorMessage: '+this.errorMessage)
          if (this.errorMessage == ' '){
            this.service.processCustomizeRoll(this.numOfDice, this.sideOfDice, this.totalRolls).subscribe(
              response =>{
                console.log('response: '+response)
                this.rollResultList = response;
                this.displayResult = 'Y'
                this.getSimulationRoll();
                this.errorMessage = ''
            }, error => {
              this.errorMessage = error
            })
          }
      }, error => {
        this.errorMessage = 'Error Encountered'
      })
    }
  }

  getSimulationRoll(){
    console.log('getSimulationRoll')
    this.service.getSimulationRoll().subscribe(
      response =>{
        console.log('response: '+response)
        this.simulationRoll = response;
        this.displaySRResult = 'Y'
    }, error => {

    })
  }

}
