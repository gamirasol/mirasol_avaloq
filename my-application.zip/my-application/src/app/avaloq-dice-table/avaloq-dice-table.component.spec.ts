import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvaloqDiceTableComponent } from './avaloq-dice-table.component';

describe('AvaloqDiceTableComponent', () => {
  let component: AvaloqDiceTableComponent;
  let fixture: ComponentFixture<AvaloqDiceTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvaloqDiceTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvaloqDiceTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
