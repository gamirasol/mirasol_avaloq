import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-avaloq-dice-table',
  templateUrl: './avaloq-dice-table.component.html',
  styleUrls: ['./avaloq-dice-table.component.css']
})
export class AvaloqDiceTableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
