import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-avaloq-footer',
  templateUrl: './avaloq-footer.component.html',
  styleUrls: ['./avaloq-footer.component.css']
})
export class AvaloqFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
