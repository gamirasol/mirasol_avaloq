import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvaloqFooterComponent } from './avaloq-footer.component';

describe('AvaloqFooterComponent', () => {
  let component: AvaloqFooterComponent;
  let fixture: ComponentFixture<AvaloqFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvaloqFooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvaloqFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
