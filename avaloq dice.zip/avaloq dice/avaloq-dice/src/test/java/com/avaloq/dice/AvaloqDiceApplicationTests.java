package com.avaloq.dice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvaloqDiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
