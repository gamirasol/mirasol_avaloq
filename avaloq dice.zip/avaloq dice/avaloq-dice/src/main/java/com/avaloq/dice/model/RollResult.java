package com.avaloq.dice.model;

public class RollResult {
	
	private Integer diceSum;
	private Integer count;
	
	protected RollResult() {}
	
	public RollResult(Integer diceSum, Integer count) {
		this.diceSum = diceSum;
		this.count = count;
	}

	public Integer getDiceSum() {
		return diceSum;
	}
	public Integer getCount() {
		return count;
	}
	public void setDiceSum(Integer diceSum) {
		this.diceSum = diceSum;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	
	

}
