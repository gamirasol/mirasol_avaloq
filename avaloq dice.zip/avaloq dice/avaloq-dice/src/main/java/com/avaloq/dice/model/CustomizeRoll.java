package com.avaloq.dice.model;

public class CustomizeRoll {

	private Integer diceSum;
	private Integer count;
	
	protected CustomizeRoll() {}

	public CustomizeRoll(Integer diceSum, Integer count) {
		super();
		this.diceSum = diceSum;
		this.count = count;
	}

	public Integer getDiceSum() {
		return diceSum;
	}

	public Integer getCount() {
		return count;
	}

	public void setDiceSum(Integer diceSum) {
		this.diceSum = diceSum;
	}

	public void setCount(Integer count) {
		this.count = count;
	}
	
}
