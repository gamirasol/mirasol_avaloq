package com.avaloq.dice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvaloqDiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvaloqDiceApplication.class, args);
	}

}
