package com.avaloq.dice.model;

public class SimulationRoll {
	
	private Integer normalTotalSumRoll;
	private Integer normalTotalRoll;
	private Integer customizeTotalSumRoll;
	private Integer customizeTotalRoll;
	private Integer totalRoll;
	private Integer totalSumRoll;
	
	protected SimulationRoll() {}

	public SimulationRoll(Integer normalTotalSumRoll, Integer normalTotalRoll, Integer customizeTotalSumRoll,
			Integer customizeTotalRoll, Integer totalRoll, Integer totalSumRoll) {
		super();
		this.normalTotalSumRoll = normalTotalSumRoll;
		this.normalTotalRoll = normalTotalRoll;
		this.customizeTotalSumRoll = customizeTotalSumRoll;
		this.customizeTotalRoll = customizeTotalRoll;
		this.totalRoll = totalRoll;
		this.totalSumRoll = totalSumRoll;
	}

	public Integer getNormalTotalSumRoll() {
		return normalTotalSumRoll;
	}

	public Integer getNormalTotalRoll() {
		return normalTotalRoll;
	}

	public Integer getCustomizeTotalSumRoll() {
		return customizeTotalSumRoll;
	}

	public Integer getCustomizeTotalRoll() {
		return customizeTotalRoll;
	}

	public Integer getTotalRoll() {
		return totalRoll;
	}

	public Integer getTotalSumRoll() {
		return totalSumRoll;
	}

	public void setNormalTotalSumRoll(Integer normalTotalSumRoll) {
		this.normalTotalSumRoll = normalTotalSumRoll;
	}

	public void setNormalTotalRoll(Integer normalTotalRoll) {
		this.normalTotalRoll = normalTotalRoll;
	}

	public void setCustomizeTotalSumRoll(Integer customizeTotalSumRoll) {
		this.customizeTotalSumRoll = customizeTotalSumRoll;
	}

	public void setCustomizeTotalRoll(Integer customizeTotalRoll) {
		this.customizeTotalRoll = customizeTotalRoll;
	}

	public void setTotalRoll(Integer totalRoll) {
		this.totalRoll = totalRoll;
	}

	public void setTotalSumRoll(Integer totalSumRoll) {
		this.totalSumRoll = totalSumRoll;
	}

	
}
