package com.avaloq.dice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.avaloq.dice.bean.Avaloq;

@Repository
public interface AvaloqJPARepository extends JpaRepository<Avaloq, Long>{
	
	int countByType(String type);

	@Query(value = "SELECT SUM(total) FROM avaloq", nativeQuery=true)
	Integer selectTotal();
	
	@Query(value = "SELECT SUM(total) FROM avaloq where type=:type", nativeQuery=true)
	Integer selectTotalByType(@Param("type") String type);
	
}
