package com.avaloq.dice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.avaloq.dice.model.RollResult;
import com.avaloq.dice.model.SimulationRoll;
import com.avaloq.dice.model.Validation;
import com.avaloq.dice.service.AvaloqService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class AvaloqController {

	@Autowired
	private AvaloqService service;
	
	@GetMapping("/avaloq/processNormalRoll")
	public List<RollResult> processNormalRoll() throws Exception{
		System.out.println("processNormalRoll >>>>>>>>>>>>");
		return service.processNormalRoll();
	}
	
	@GetMapping("/avaloq/processCustomizeRoll/numOfDice/{numOfDice}/sideOfDice/{sideOfDice}/totalRolls/{totalRolls}")
	public List<RollResult> processCustomizeRoll(@PathVariable Integer numOfDice, 
			@PathVariable Integer sideOfDice,
			@PathVariable Integer totalRolls) throws Exception{
		
		System.out.println("processCustomizeRoll >>>>>>>>>>>>");
		return service.processCustomizeRoll(numOfDice, sideOfDice, totalRolls);
	}
	
	@GetMapping("/avaloq/getSimulationRoll")
	public SimulationRoll getSimulationRoll() throws Exception{
		System.out.println("getSimulationRoll >>>>>>>>>>>>");
		return service.getSimulationRoll();
	}
	
	@GetMapping("/avaloq/validateEntry/numOfDice/{numOfDice}/sideOfDice/{sideOfDice}/totalRolls/{totalRolls}")
	public Validation validateEntry(@PathVariable Integer numOfDice, 
			@PathVariable Integer sideOfDice,
			@PathVariable Integer totalRolls) throws Exception{
		
		System.out.println("validateEntry >>>>>>>>>>>>");
		
		Validation errorMessage = new Validation(" ");
		
		if (numOfDice == null || numOfDice < 1){
			errorMessage.setErrorMessage("Invalid Number of Dice!");
		    return errorMessage;
		}
		else if (sideOfDice == null || sideOfDice < 4 || (1 == sideOfDice % 2)){
			errorMessage.setErrorMessage("Invalid Number Side of Dice!");
			return errorMessage;
		}
		else if (totalRolls == null || totalRolls < 1){
			errorMessage.setErrorMessage("Invalid Number Total Roll!");
		    return errorMessage;
		}
		
		
		return errorMessage;
	}
	
}
