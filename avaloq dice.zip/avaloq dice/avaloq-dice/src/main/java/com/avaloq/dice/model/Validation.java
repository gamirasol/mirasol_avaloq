package com.avaloq.dice.model;

public class Validation {

	private String errorMessage;

	protected Validation() {}

	public Validation(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
		
}
