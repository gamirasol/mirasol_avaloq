package com.avaloq.dice.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avaloq.dice.bean.Avaloq;
import com.avaloq.dice.bean.TotalSum;
import com.avaloq.dice.model.RollResult;
import com.avaloq.dice.model.SimulationRoll;
import com.avaloq.dice.repository.AvaloqJPARepository;

@Service
public class AvaloqService {

	@Autowired
	private AvaloqJPARepository repository;
	
	public List<RollResult> processNormalRoll() throws Exception{
		
		List<TotalSum> totalSumList = new ArrayList<TotalSum>();
		TotalSum totalSum;
		
		Random rd = new Random();
		
		int dice1;
		int dice2;
		int dice3;
		
		int sum;
		
		int counter = 1;
		
		while(counter <=100) {
			dice1 = 1 + rd.nextInt(6);
			dice2 = 1 + rd.nextInt(6);
			dice3 = 1 + rd.nextInt(6);
			sum = dice1 + dice2 + dice3;
			
			totalSum = new TotalSum(sum);
			totalSumList.add(totalSum);
			
			++counter;
		}
		
		Map<Integer, Long> result = totalSumList.stream()
				.collect(Collectors.groupingBy(TotalSum::getSum, Collectors.counting()));
		
		Iterator<Map.Entry<Integer, Long>> iterator =
		result.entrySet().iterator();
		
		List<RollResult> resultList = new ArrayList<RollResult>();
		RollResult normalRoll;
		
		while(iterator.hasNext()) {
			Map.Entry<Integer, Long> entry = iterator.next();
			normalRoll = new RollResult(entry.getKey(), Math.toIntExact(entry.getValue()));
			resultList.add(normalRoll);
		}
		
		Avaloq avaloqEntity = new Avaloq(null, 100, "Normal Rolls");
		
		repository.save(avaloqEntity);
		
		this.getSimulationRoll();

		return resultList;
	}
	
	public List<RollResult> processCustomizeRoll(int numOfDice, int sideOfDice, int totalRolls) {
		
		if (numOfDice < 1 || totalRolls < 1) {
			System.out.println("Invalid Number of Dice and Invalid Number of Rolls!");
		}
		if (sideOfDice < 4 || sideOfDice % 2 == 1) {
			System.out.println("Invalid Number of Dice!");
		}
		
		Random rd = new Random();
		List<TotalSum> totalSumList = new ArrayList<TotalSum>();
		TotalSum totalSum;
		
		
		for(int counter = 1; counter <=totalRolls; counter++){
			int initialSum = 0;
			for (int x = 0; x < numOfDice; x++) {
				initialSum = initialSum + 1 + rd.nextInt(sideOfDice); 
			}
			totalSum = new TotalSum(initialSum);
			totalSumList.add(totalSum);
		}
		
		Map<Integer, Long> result2 = totalSumList.stream()
				.collect(Collectors.groupingBy(TotalSum::getSum, Collectors.counting()));
		

		Iterator<Map.Entry<Integer, Long>> iterator =
		result2.entrySet().iterator();
		
		List<RollResult> resultList = new ArrayList<RollResult>();
		RollResult customizeRoll;
		
		while(iterator.hasNext()) {
			Map.Entry<Integer, Long> entry = iterator.next();
			customizeRoll = new RollResult(entry.getKey(), Math.toIntExact(entry.getValue()));
			resultList.add(customizeRoll);
		}
		
		Avaloq avaloqEntity = new Avaloq(null, totalRolls, "Customize Rolls");
		
		repository.save(avaloqEntity);
		
		this.getSimulationRoll();

		return resultList;
	}
	
	public SimulationRoll getSimulationRoll() {
		
		int normalTotalSumRoll = repository.selectTotalByType("Normal Rolls");
		int normalTotalRoll = repository.countByType("Normal Rolls")-1;
		int customizeTotalSumRoll = repository.selectTotalByType("Customize Rolls");
		int customizeTotalRoll = repository.countByType("Customize Rolls")-1;
		int totalRoll = normalTotalRoll+customizeTotalRoll;
		int totalSumRoll = normalTotalSumRoll+customizeTotalSumRoll;
		
		System.out.println("normalTotalSumRoll: "+normalTotalSumRoll);
		System.out.println("normalTotalRoll: "+normalTotalRoll);
		System.out.println("customizeTotalSumRoll: "+customizeTotalSumRoll);
		System.out.println("customizeTotalRoll: "+customizeTotalRoll);
		System.out.println("customizeTotalRoll: "+customizeTotalRoll);
		System.out.println("totalRoll: "+totalRoll);
		System.out.println("totalSumRoll: "+totalSumRoll);
		
		SimulationRoll simulationRoll = new SimulationRoll(normalTotalSumRoll,
				normalTotalRoll, customizeTotalSumRoll, customizeTotalRoll, totalRoll, totalSumRoll);
		
		return simulationRoll;
	}
}
