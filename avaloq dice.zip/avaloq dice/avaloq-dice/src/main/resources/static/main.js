(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _avaloq_dice_main_avaloq_dice_main_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./avaloq-dice-main/avaloq-dice-main.component */ "./src/app/avaloq-dice-main/avaloq-dice-main.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    { path: '', component: _avaloq_dice_main_avaloq_dice_main_component__WEBPACK_IMPORTED_MODULE_2__["AvaloqDiceMainComponent"] },
    { path: 'home', component: _avaloq_dice_main_avaloq_dice_main_component__WEBPACK_IMPORTED_MODULE_2__["AvaloqDiceMainComponent"] }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-avaloq-header></app-avaloq-header>\n<div class=\"container\">\n  <div class=\"col\"></div>\n  <router-outlet></router-outlet>\n</div>\n<app-avaloq-footer></app-avaloq-footer>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'my-application';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _avaloq_dice_main_avaloq_dice_main_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./avaloq-dice-main/avaloq-dice-main.component */ "./src/app/avaloq-dice-main/avaloq-dice-main.component.ts");
/* harmony import */ var _avaloq_dice_table_avaloq_dice_table_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./avaloq-dice-table/avaloq-dice-table.component */ "./src/app/avaloq-dice-table/avaloq-dice-table.component.ts");
/* harmony import */ var _avaloq_header_avaloq_header_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./avaloq-header/avaloq-header.component */ "./src/app/avaloq-header/avaloq-header.component.ts");
/* harmony import */ var _avaloq_footer_avaloq_footer_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./avaloq-footer/avaloq-footer.component */ "./src/app/avaloq-footer/avaloq-footer.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"],
                _avaloq_dice_main_avaloq_dice_main_component__WEBPACK_IMPORTED_MODULE_6__["AvaloqDiceMainComponent"],
                _avaloq_dice_table_avaloq_dice_table_component__WEBPACK_IMPORTED_MODULE_7__["AvaloqDiceTableComponent"],
                _avaloq_header_avaloq_header_component__WEBPACK_IMPORTED_MODULE_8__["AvaloqHeaderComponent"],
                _avaloq_footer_avaloq_footer_component__WEBPACK_IMPORTED_MODULE_9__["AvaloqFooterComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppRoutingModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"]
            ],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/avaloq-dice-main/avaloq-dice-main.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/avaloq-dice-main/avaloq-dice-main.component.css ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2F2YWxvcS1kaWNlLW1haW4vYXZhbG9xLWRpY2UtbWFpbi5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/avaloq-dice-main/avaloq-dice-main.component.html":
/*!******************************************************************!*\
  !*** ./src/app/avaloq-dice-main/avaloq-dice-main.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<div class=\"container\">\n  <div class=\"row custom-wrapper\">\n    <div class=\"col-md-12\">\n      <form class=\"text-left border border-dark p-5 col-xs-3\">\n        <table>\n          <div class=\"form-row mb-4\" *ngIf=\"errorMessage\">\n            <div class=\"p-3 mb-2 bg-warning text-dark\">\n              {{errorMessage}}\n            </div>  \n          </div>\n          <div class=\"row\">\n            <p class=\"h4 text-left\">\n              <span id=\"title\">Roll Normal Dice</span>\n            </p>\n          </div>\n          <div class=\"row\">\n            <div class=\"col-md-3 my-3\">\n              <button (click)=\"rollNormalDice()\"\n                class=\"btn btn-primary btn-square waves-effect waves-light\">Roll</button>\n            </div>\n          </div>\n          <tr>\n            <td>\n              <div class=\"row\">\n                <p class=\"h4 text-left\">\n                  <span id=\"title\">Roll Customize Dice</span>\n                </p>\n              </div>\n              <div class=\"form-group mx-sm-3 mb-2\">\n                <div class=\"row\">\n                  <label for=\"title\">Enter Number of Dice: </label>\n                  <input type=\"text\" class=\"form-control\" name=\"numOfDice\" [(ngModel)]=\"numOfDice\">\n                </div>\n                <div class=\"row\">\n                  <label for=\"title\">Enter Number Side of Dice: </label>\n                  <input type=\"text\" class=\"form-control\" name=\"sideOfDice\" [(ngModel)]=\"sideOfDice\">\n                </div>\n              </div>\n              <div class=\"form-group mx-sm-3 mb-2\">\n                <div class=\"row\">\n                  <label for=\"title\">Enter Number of Total Rolls: </label>\n                  <input type=\"text\" class=\"form-control\" name=\"totalRolls\" [(ngModel)]=\"totalRolls\">\n                </div>\n              </div>\n              <div class=\"row\">\n                <div class=\"col-md-3 my-3\">\n                  <button (click)=\"rollCustomizeDice()\" class=\"btn btn-primary btn-square waves-effect waves-light\">Roll\n                    Customize</button>\n                </div>\n              </div>\n            </td>\n            <td>\n              <div class=\"container\">\n                <div class=\"col\">\n                  <div class=\"row\">\n                    <table class=\"table table-bordered\" *ngIf=\"displayResult\">\n                     <tr>\n                       <td>\n                        <label for=\"title\">Sum</label>\n                       </td>\n                       <td>\n                        <label for=\"title\">Count of Sum has been rolled</label>\n                       </td>\n                     </tr>\n                      <tbody>\n                        <tr *ngFor=\"let rollResult of rollResultList\">\n                          <td>{{rollResult.diceSum}}</td>\n                          <td>{{rollResult.count}}</td>\n                        </tr>\n                      </tbody>\n                    </table>\n                  </div>\n                </div>\n              </div>\n            </td>            \n          </tr>\n          <tr>\n            <td>\n              <div class=\"container\">\n                <div class=\"col\">\n                  <div class=\"row\">\n                    <table class=\"table table-bordered\" *ngIf=\"displaySRResult\">\n                     <tr>\n                       <td>\n                        <label for=\"title\">Normal Roll Total count</label>\n                       </td>\n                       <td>\n                        <label for=\"title\">Normal Total Sum Roll</label>\n                       </td>\n                       <td>\n                        <label for=\"title\">Customize Roll Total count</label>\n                       </td>\n                       <td>\n                        <label for=\"title\">Customize Total Sum Roll</label>\n                       </td>\n                       <td>\n                        <label for=\"title\">Total Roll count</label>\n                       </td>\n                       <td>\n                        <label for=\"title\">Total Roll Sum</label>\n                       </td>\n                     </tr>\n                      <tbody>\n                        <tr>\n                          <td>{{simulationRoll.normalTotalRoll}}</td>\n                          <td>{{simulationRoll.normalTotalSumRoll}}</td>\n                          <td>{{simulationRoll.customizeTotalRoll}}</td>\n                          <td>{{simulationRoll.customizeTotalSumRoll}}</td>\n                          <td>{{simulationRoll.totalRoll}}</td>\n                          <td>{{simulationRoll.totalSumRoll}}</td>  \n                        </tr>\n                      </tbody>\n                    </table>\n                  </div>\n                </div>\n              </div>\n            </td>\n          </tr>\n        </table>\n      </form>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/avaloq-dice-main/avaloq-dice-main.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/avaloq-dice-main/avaloq-dice-main.component.ts ***!
  \****************************************************************/
/*! exports provided: RollResult, SimulationRoll, Validation, AvaloqDiceMainComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RollResult", function() { return RollResult; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SimulationRoll", function() { return SimulationRoll; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Validation", function() { return Validation; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AvaloqDiceMainComponent", function() { return AvaloqDiceMainComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_avaloq_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../service/avaloq.service */ "./src/app/service/avaloq.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var RollResult = /** @class */ (function () {
    function RollResult(diceSum, count) {
        this.diceSum = diceSum;
        this.count = count;
    }
    return RollResult;
}());

var SimulationRoll = /** @class */ (function () {
    function SimulationRoll(normalTotalSumRoll, normalTotalRoll, customizeTotalSumRoll, customizeTotalRoll, totalRoll, totalSumRoll) {
        this.normalTotalSumRoll = normalTotalSumRoll;
        this.normalTotalRoll = normalTotalRoll;
        this.customizeTotalSumRoll = customizeTotalSumRoll;
        this.customizeTotalRoll = customizeTotalRoll;
        this.totalRoll = totalRoll;
        this.totalSumRoll = totalSumRoll;
    }
    return SimulationRoll;
}());

var Validation = /** @class */ (function () {
    function Validation(errorMessage) {
        this.errorMessage = errorMessage;
    }
    return Validation;
}());

var AvaloqDiceMainComponent = /** @class */ (function () {
    function AvaloqDiceMainComponent(service) {
        this.service = service;
        this.displayResult = '';
        this.displaySRResult = '';
    }
    AvaloqDiceMainComponent.prototype.ngOnInit = function () {
    };
    AvaloqDiceMainComponent.prototype.rollNormalDice = function () {
        var _this = this;
        this.errorMessage = '';
        this.numOfDice = 0;
        this.sideOfDice = 0;
        this.totalRolls = 0;
        console.log('rollNormalDice');
        this.service.processNormalDice().subscribe(function (response) {
            console.log('response: ' + response);
            _this.rollResultList = response;
            _this.displayResult = 'Y';
            _this.getSimulationRoll();
        }, function (error) {
            _this.errorMessage = error;
        });
    };
    AvaloqDiceMainComponent.prototype.rollCustomizeDice = function () {
        var _this = this;
        this.errorMessage = '';
        console.log('rollCustomizeDice: numOfDice: ' + this.numOfDice + ' sideOfDice: ' + this.sideOfDice + ' totalRolls: ' + this.totalRolls);
        if (this.numOfDice == null || this.sideOfDice == null || this.totalRolls == null) {
            this.errorMessage = 'Invalid Number of Dice!';
            return;
        }
        else if (this.sideOfDice == null) {
            this.errorMessage = 'Invalid Number Side of Dice!';
            return;
        }
        else if (this.totalRolls == null) {
            this.errorMessage = 'Invalid Number Total Rolls!';
            return;
        }
        else {
            this.service.validateEntry(this.numOfDice, this.sideOfDice, this.totalRolls).subscribe(function (response) {
                console.log('response: ' + response);
                _this.validation = response;
                _this.errorMessage = _this.validation.errorMessage;
                console.log('errorMessage: ' + _this.errorMessage);
                if (_this.errorMessage == ' ') {
                    _this.service.processCustomizeRoll(_this.numOfDice, _this.sideOfDice, _this.totalRolls).subscribe(function (response) {
                        console.log('response: ' + response);
                        _this.rollResultList = response;
                        _this.displayResult = 'Y';
                        _this.getSimulationRoll();
                        _this.errorMessage = '';
                    }, function (error) {
                        _this.errorMessage = error;
                    });
                }
            }, function (error) {
                _this.errorMessage = 'Error Encountered';
            });
        }
    };
    AvaloqDiceMainComponent.prototype.getSimulationRoll = function () {
        var _this = this;
        console.log('getSimulationRoll');
        this.service.getSimulationRoll().subscribe(function (response) {
            console.log('response: ' + response);
            _this.simulationRoll = response;
            _this.displaySRResult = 'Y';
        }, function (error) {
        });
    };
    AvaloqDiceMainComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-avaloq-dice-main',
            template: __webpack_require__(/*! ./avaloq-dice-main.component.html */ "./src/app/avaloq-dice-main/avaloq-dice-main.component.html"),
            styles: [__webpack_require__(/*! ./avaloq-dice-main.component.css */ "./src/app/avaloq-dice-main/avaloq-dice-main.component.css")]
        }),
        __metadata("design:paramtypes", [_service_avaloq_service__WEBPACK_IMPORTED_MODULE_1__["AvaloqService"]])
    ], AvaloqDiceMainComponent);
    return AvaloqDiceMainComponent;
}());



/***/ }),

/***/ "./src/app/avaloq-dice-table/avaloq-dice-table.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/avaloq-dice-table/avaloq-dice-table.component.css ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2F2YWxvcS1kaWNlLXRhYmxlL2F2YWxvcS1kaWNlLXRhYmxlLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/avaloq-dice-table/avaloq-dice-table.component.html":
/*!********************************************************************!*\
  !*** ./src/app/avaloq-dice-table/avaloq-dice-table.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  avaloq-dice-table works!\n</p>\n"

/***/ }),

/***/ "./src/app/avaloq-dice-table/avaloq-dice-table.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/avaloq-dice-table/avaloq-dice-table.component.ts ***!
  \******************************************************************/
/*! exports provided: AvaloqDiceTableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AvaloqDiceTableComponent", function() { return AvaloqDiceTableComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var AvaloqDiceTableComponent = /** @class */ (function () {
    function AvaloqDiceTableComponent() {
    }
    AvaloqDiceTableComponent.prototype.ngOnInit = function () {
    };
    AvaloqDiceTableComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-avaloq-dice-table',
            template: __webpack_require__(/*! ./avaloq-dice-table.component.html */ "./src/app/avaloq-dice-table/avaloq-dice-table.component.html"),
            styles: [__webpack_require__(/*! ./avaloq-dice-table.component.css */ "./src/app/avaloq-dice-table/avaloq-dice-table.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], AvaloqDiceTableComponent);
    return AvaloqDiceTableComponent;
}());



/***/ }),

/***/ "./src/app/avaloq-footer/avaloq-footer.component.css":
/*!***********************************************************!*\
  !*** ./src/app/avaloq-footer/avaloq-footer.component.css ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2F2YWxvcS1mb290ZXIvYXZhbG9xLWZvb3Rlci5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/avaloq-footer/avaloq-footer.component.html":
/*!************************************************************!*\
  !*** ./src/app/avaloq-footer/avaloq-footer.component.html ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  Avaloq All Rights Reserved 2020!\n</p>\n"

/***/ }),

/***/ "./src/app/avaloq-footer/avaloq-footer.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/avaloq-footer/avaloq-footer.component.ts ***!
  \**********************************************************/
/*! exports provided: AvaloqFooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AvaloqFooterComponent", function() { return AvaloqFooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var AvaloqFooterComponent = /** @class */ (function () {
    function AvaloqFooterComponent() {
    }
    AvaloqFooterComponent.prototype.ngOnInit = function () {
    };
    AvaloqFooterComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-avaloq-footer',
            template: __webpack_require__(/*! ./avaloq-footer.component.html */ "./src/app/avaloq-footer/avaloq-footer.component.html"),
            styles: [__webpack_require__(/*! ./avaloq-footer.component.css */ "./src/app/avaloq-footer/avaloq-footer.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], AvaloqFooterComponent);
    return AvaloqFooterComponent;
}());



/***/ }),

/***/ "./src/app/avaloq-header/avaloq-header.component.css":
/*!***********************************************************!*\
  !*** ./src/app/avaloq-header/avaloq-header.component.css ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2F2YWxvcS1oZWFkZXIvYXZhbG9xLWhlYWRlci5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/avaloq-header/avaloq-header.component.html":
/*!************************************************************!*\
  !*** ./src/app/avaloq-header/avaloq-header.component.html ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar navbar-default navbar-fixed-top custom-navbar\">\n  <div class=\"container-fluid\">\n    <div class=\"navbar-header\">\n      <a class=\"navbar-brand\" href=\"#\"><img src=\"../assets/img/avaloqLogo.JPG\"></a>\n    </div>\n    <div class=\"pull-right\">\n      <p class=\"h3 text-left\">\n        <span id=\"title\">Avaloq Dice</span>\n      </p>\n    </div>\n  </div>\n</nav>\n"

/***/ }),

/***/ "./src/app/avaloq-header/avaloq-header.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/avaloq-header/avaloq-header.component.ts ***!
  \**********************************************************/
/*! exports provided: AvaloqHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AvaloqHeaderComponent", function() { return AvaloqHeaderComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var AvaloqHeaderComponent = /** @class */ (function () {
    function AvaloqHeaderComponent() {
    }
    AvaloqHeaderComponent.prototype.ngOnInit = function () {
    };
    AvaloqHeaderComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-avaloq-header',
            template: __webpack_require__(/*! ./avaloq-header.component.html */ "./src/app/avaloq-header/avaloq-header.component.html"),
            styles: [__webpack_require__(/*! ./avaloq-header.component.css */ "./src/app/avaloq-header/avaloq-header.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], AvaloqHeaderComponent);
    return AvaloqHeaderComponent;
}());



/***/ }),

/***/ "./src/app/service/avaloq.service.ts":
/*!*******************************************!*\
  !*** ./src/app/service/avaloq.service.ts ***!
  \*******************************************/
/*! exports provided: AvaloqService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AvaloqService", function() { return AvaloqService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AvaloqService = /** @class */ (function () {
    function AvaloqService(http) {
        this.http = http;
    }
    AvaloqService.prototype.processNormalDice = function () {
        return this.http.get('http://localhost:4200/avaloq/processNormalRoll');
    };
    AvaloqService.prototype.processCustomizeRoll = function (numOfDice, sideOfDice, totalRolls) {
        return this.http.get("http://localhost:4200/avaloq/processCustomizeRoll/numOfDice/" + numOfDice + "/sideOfDice/" + sideOfDice + "/totalRolls/" + totalRolls);
    };
    AvaloqService.prototype.getSimulationRoll = function () {
        return this.http.get('http://localhost:4200/avaloq/getSimulationRoll');
    };
    AvaloqService.prototype.validateEntry = function (numOfDice, sideOfDice, totalRolls) {
        return this.http.get("http://localhost:4200/avaloq/validateEntry/numOfDice/" + numOfDice + "/sideOfDice/" + sideOfDice + "/totalRolls/" + totalRolls);
    };
    AvaloqService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], AvaloqService);
    return AvaloqService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Development\Temp\my-application\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map