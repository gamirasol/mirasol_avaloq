insert into avaloq(id, total, type)
values(1001, 0, 'Normal Rolls');

insert into avaloq(id, total, type)
values(1002, 0, 'Customize Rolls');